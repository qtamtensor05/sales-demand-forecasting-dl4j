package com.dl4j.salesforecast.preprocessing;

import com.dl4j.salesforecast.analysis.TimeSeriesAnalyzer.TimeSeriesResult;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/** Chronological splitting and train-only scaling; no model training. */
public final class SalesPreprocessor {
    private static final int LAG_DAYS = 7;
    private static final int ROLLING_SHORT_DAYS = 7;
    private static final int ROLLING_LONG_DAYS = 14;
    private static final int FEATURE_HISTORY_DAYS = ROLLING_LONG_DAYS;
    private static final int FIRST_FEATURE_DAY_INDEX = FEATURE_HISTORY_DAYS - 1;
    private static final List<String> INPUT_FEATURE_NAMES = List.of(
            "sales", "sales_lag_7", "rolling_mean_7", "rolling_mean_14",
            "day_of_week_sin", "day_of_week_cos");

    private SalesPreprocessor() { }

    public static List<String> getInputFeatureNames() { return INPUT_FEATURE_NAMES; }

    /** Defaults for the Store Item Demand Forecasting dataset. */
    public static PreprocessingResult preprocess(TimeSeriesResult series) {
        return preprocess(series, LocalDate.of(2015, 12, 31),
                LocalDate.of(2016, 12, 31), 30, 7);
    }

    /** Split end dates are inclusive. Test includes all remaining observations. */
    public static PreprocessingResult preprocess(TimeSeriesResult series,
                                                LocalDate trainEnd, LocalDate validationEnd,
                                                int inputDays, int forecastDays) {
        return preprocess(series, trainEnd, validationEnd, inputDays, forecastDays, null);
    }
    public static PreprocessingResult preprocess(TimeSeriesResult series,
                                                LocalDate trainEnd, LocalDate validationEnd,
                                                int inputDays, int forecastDays,
                                                com.dl4j.salesforecast.performance.GlobalPerformanceProfile profile) {
        Objects.requireNonNull(series, "series");
        Objects.requireNonNull(trainEnd, "trainEnd");
        Objects.requireNonNull(validationEnd, "validationEnd");
        if (!series.isComplete()) {
            throw new IllegalArgumentException("Series must have exactly one record per day; fix gaps/duplicates first.");
        }
        if (inputDays <= 0 || forecastDays <= 0) {
            throw new IllegalArgumentException("Window lengths must be positive.");
        }
        if (trainEnd.isBefore(series.getStartDate()) || !trainEnd.isBefore(validationEnd)
                || !validationEnd.isBefore(series.getEndDate())) {
            throw new IllegalArgumentException("Split dates must define non-empty chronological train/validation/test sets.");
        }
        List<LocalDate> dates = series.getDates();
        List<Double> raw = series.getSales();
        int trainSize = 0;
        int validationLimit = 0;
        for (LocalDate date : dates) {
            if (!date.isAfter(trainEnd)) { trainSize++; }
            if (!date.isAfter(validationEnd)) { validationLimit++; }
        }
        if ((long) trainSize < (long) inputDays + FIRST_FEATURE_DAY_INDEX + forecastDays
                || validationLimit - trainSize < forecastDays
                || dates.size() - validationLimit < forecastDays) {
            throw new IllegalArgumentException("Each split must contain a full target window; train also needs "
                    + FEATURE_HISTORY_DAYS + " days of causal feature history before its input window.");
        }

        long started = System.nanoTime();
        double min = Double.POSITIVE_INFINITY;
        double max = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < trainSize; i++) {
            min = Math.min(min, raw.get(i));
            max = Math.max(max, raw.get(i));
        }
        MinMaxScaler scaler = new MinMaxScaler(min, max);
        if (profile != null) { profile.record("data.scalers", started); }
        started = System.nanoTime();
        List<Double> normalized = new ArrayList<>();
        for (double value : raw) { normalized.add(scaler.transform(value)); }
        List<List<Double>> inputFeatures = createInputFeatures(dates, raw, scaler);
        if (profile != null) { profile.record("data.features", started); }
        started = System.nanoTime();
        Split train = createSplit("TRAIN", 0, trainSize, dates, raw, normalized, inputFeatures,
                inputDays, forecastDays);
        Split validation = createSplit("VALIDATION", trainSize, validationLimit,
                dates, raw, normalized, inputFeatures, inputDays, forecastDays);
        Split test = createSplit("TEST", validationLimit, dates.size(),
                dates, raw, normalized, inputFeatures, inputDays, forecastDays);
        if (profile != null) { profile.record("data.windows", started); }
        return new PreprocessingResult(series.getStoreId(), series.getItemId(), inputDays,
                forecastDays, scaler, train, validation, test);
    }

    private static Split createSplit(String name, int from, int to, List<LocalDate> dates,
                                     List<Double> raw, List<Double> normalized,
                                     List<List<Double>> inputFeatures,
                                     int inputDays, int forecastDays) {
        List<Window> windows = new ArrayList<>();
        // Targets stay inside this split; causal features need 14 days before the input starts.
        int firstFeatureReadyTarget = inputDays + FIRST_FEATURE_DAY_INDEX;
        for (int target = Math.max(from, firstFeatureReadyTarget); target <= to - forecastDays; target++) {
            windows.add(new Window(dates.subList(target - inputDays, target),
                    dates.subList(target, target + forecastDays),
                    raw.subList(target - inputDays, target), raw.subList(target, target + forecastDays),
                    normalized.subList(target - inputDays, target),
                    normalized.subList(target, target + forecastDays),
                    inputFeatures.subList(target - inputDays, target)));
        }
        return new Split(name, dates.subList(from, to), raw.subList(from, to),
                normalized.subList(from, to), windows);
    }

    /** All sales-derived features use observations on or before their feature date. */
    private static List<List<Double>> createInputFeatures(List<LocalDate> dates, List<Double> raw,
                                                          MinMaxScaler scaler) {
        List<List<Double>> features = new ArrayList<>(raw.size());
        for (int day = 0; day < raw.size(); day++) {
            if (day < FIRST_FEATURE_DAY_INDEX) {
                features.add(List.of());
                continue;
            }
            double rolling7 = mean(raw, day - ROLLING_SHORT_DAYS + 1, day + 1);
            double rolling14 = mean(raw, day - ROLLING_LONG_DAYS + 1, day + 1);
            int dayOfWeek = dates.get(day).getDayOfWeek().getValue() - 1; // Monday = 0
            double angle = 2.0 * Math.PI * dayOfWeek / 7.0;
            features.add(List.of(
                    scaler.transform(raw.get(day)),
                    scaler.transform(raw.get(day - LAG_DAYS)),
                    scaler.transform(rolling7),
                    scaler.transform(rolling14),
                    Math.sin(angle),
                    Math.cos(angle)));
        }
        return features;
    }

    private static double mean(List<Double> values, int fromInclusive, int toExclusive) {
        double sum = 0.0;
        for (int i = fromInclusive; i < toExclusive; i++) { sum += values.get(i); }
        return sum / (toExclusive - fromInclusive);
    }

    public static void printSummary(PreprocessingResult result) {
        System.out.println("\n==========================================\nSALES PREPROCESSING\n==========================================");
        System.out.printf("Store / Item : %d / %d%nWindow       : %d -> %d days%n",
                result.storeId, result.itemId, result.inputDays, result.forecastDays);
        System.out.println("Input features: " + INPUT_FEATURE_NAMES);
        System.out.printf("Feature warm-up: %d days (windows start after causal history is available)%n",
                FEATURE_HISTORY_DAYS);
        System.out.printf(Locale.ROOT, "Train min/max: %.0f / %.0f%n", result.scaler.min, result.scaler.max);
        System.out.println("Scaler fitted on train only; values are not clipped.");
        System.out.println("Validation/test use observed history before each forecast.");
        for (Split split : List.of(result.train, result.validation, result.test)) {
            System.out.printf("%n%s%nDates   : %s -> %s%nDays    : %d%nWindows : %d%n",
                    split.name, split.dates.get(0), split.dates.get(split.dates.size() - 1),
                    split.dates.size(), split.windows.size());
            Window first = split.windows.get(0);
            Window last = split.windows.get(split.windows.size() - 1);
            System.out.printf("First input  : %s -> %s%nFirst target : %s -> %s%nLast target  : %s -> %s%n",
                    first.inputDates.get(0), first.inputDates.get(first.inputDates.size() - 1),
                    first.targetDates.get(0), first.targetDates.get(first.targetDates.size() - 1),
                    last.targetDates.get(0), last.targetDates.get(last.targetDates.size() - 1));
            printValues("First input (raw -> scaled)", first.rawInput, first.input);
            printValues("First target (raw -> scaled)", first.rawTarget, first.target);
        }
    }

    private static void printValues(String label, List<Double> raw, List<Double> scaled) {
        System.out.println(label);
        for (int i = 0; i < raw.size(); i++) {
            System.out.printf(Locale.ROOT, "  %2d: %6.0f -> %.4f%n", i + 1, raw.get(i), scaled.get(i));
        }
    }

    public static final class MinMaxScaler {
        private final double min;
        private final double max;
        private final double scale;

        private MinMaxScaler(double min, double max) {
            this.min = min;
            this.max = max;
            // Constant training series maps to zero, with a reversible unit scale.
            this.scale = max == min ? 1.0 : max - min;
        }
        public double transform(double value) { return (value - min) / scale; }
        public double inverseTransform(double value) { return value * scale + min; }
        public double getMin() { return min; }
        public double getMax() { return max; }
        public double getScale() { return scale; }
    }

    public static final class Window {
        private final List<LocalDate> inputDates;
        private final List<LocalDate> targetDates;
        private final List<Double> rawInput;
        private final List<Double> rawTarget;
        private final List<Double> input;
        private final List<Double> target;
        private final List<List<Double>> inputFeatures;

        private Window(List<LocalDate> inputDates, List<LocalDate> targetDates,
                       List<Double> rawInput, List<Double> rawTarget,
                       List<Double> input, List<Double> target, List<List<Double>> inputFeatures) {
            this.inputDates = List.copyOf(inputDates);
            this.targetDates = List.copyOf(targetDates);
            this.rawInput = List.copyOf(rawInput);
            this.rawTarget = List.copyOf(rawTarget);
            this.input = List.copyOf(input);
            this.target = List.copyOf(target);
            List<List<Double>> copiedFeatures = new ArrayList<>(inputFeatures.size());
            for (List<Double> row : inputFeatures) { copiedFeatures.add(List.copyOf(row)); }
            this.inputFeatures = List.copyOf(copiedFeatures);
        }
        public List<LocalDate> getInputDates() { return inputDates; }
        public List<LocalDate> getTargetDates() { return targetDates; }
        public List<Double> getRawInput() { return rawInput; }
        public List<Double> getRawTarget() { return rawTarget; }
        public List<Double> getInput() { return input; }
        public List<Double> getTarget() { return target; }
        /** One immutable feature vector per input day, in getInputFeatureNames() order. */
        public List<List<Double>> getInputFeatures() { return inputFeatures; }
    }

    public static final class Split {
        private final String name;
        private final List<LocalDate> dates;
        private final List<Double> rawSales;
        private final List<Double> normalizedSales;
        private final List<Window> windows;

        private Split(String name, List<LocalDate> dates, List<Double> rawSales,
                      List<Double> normalizedSales, List<Window> windows) {
            this.name = name;
            this.dates = List.copyOf(dates);
            this.rawSales = List.copyOf(rawSales);
            this.normalizedSales = List.copyOf(normalizedSales);
            this.windows = List.copyOf(windows);
        }
        public String getName() { return name; }
        public List<LocalDate> getDates() { return dates; }
        public List<Double> getRawSales() { return rawSales; }
        public List<Double> getNormalizedSales() { return normalizedSales; }
        public List<Window> getWindows() { return windows; }
    }

    public static final class PreprocessingResult {
        private final int storeId;
        private final int itemId;
        private final int inputDays;
        private final int forecastDays;
        private final MinMaxScaler scaler;
        private final Split train;
        private final Split validation;
        private final Split test;

        private PreprocessingResult(int storeId, int itemId, int inputDays, int forecastDays,
                                    MinMaxScaler scaler, Split train, Split validation, Split test) {
            this.storeId = storeId;
            this.itemId = itemId;
            this.inputDays = inputDays;
            this.forecastDays = forecastDays;
            this.scaler = scaler;
            this.train = train;
            this.validation = validation;
            this.test = test;
        }
        public int getStoreId() { return storeId; }
        public int getItemId() { return itemId; }
        public int getInputDays() { return inputDays; }
        public int getForecastDays() { return forecastDays; }
        public MinMaxScaler getScaler() { return scaler; }
        public Split getTrain() { return train; }
        public Split getValidation() { return validation; }
        public Split getTest() { return test; }
    }
}
